args <- commandArgs(trailingOnly = TRUE)

if(length(args)<4)
{
	cat("Insufficient arguments!\n")
	cat("Please run the script like: Rscript main.R <b/c> <h/s> <input_file> <output_file>\n")
	cat("Example: Rscript main.R b h input.txt output.txt\n")
	cat("b:\tBP ontology\tc:CC ontology\n")
	cat("h:\thuman annotation \ts:\tyeast annotation\n")
	q(save = "no", status = 0, runLast = TRUE)

} else if(length(args)>4)
{
	cat("More than required arguments!\n")
	cat("Please run the script like: Rscript main.R <b/c> <h/s> <input_file> <output_file>\n")
	cat("Example: Rscript main.R b h input.txt output.txt\n")
	cat("b:\tBP ontology\tc:CC ontology\n")
	cat("h:\thuman annotation \ts:\tyeast annotation\n")
	q(save = "no", status = 0, runLast = TRUE)

} else if(args[1]=='b' && args[2]=='h')
{
	input_file=args[3]
	out_file=args[4]
	p_dir=getwd()
	ch_dir=paste(p_dir,"/Script/Human/BP/Run/",sep="")
	setwd(ch_dir)
	source("Load.R")
	setwd(p_dir)
	sim.from.file(input_file,out_file)
} else if(args[1]=='b' && args[2]=='s')
{
	input_file=args[3]
	out_file=args[4]
	p_dir=getwd()
	ch_dir=paste(p_dir,"/Script/Yeast/BP/Run/",sep="")
	setwd(ch_dir)
	source("Load.R")
	setwd(p_dir)
	sim.from.file(input_file,out_file)

} else if(args[1]=='c' && args[2]=='h')
{

	input_file=args[3]
	out_file=args[4]
	p_dir=getwd()
	ch_dir=paste(p_dir,"/Script/Human/CC/Run/",sep="")
	setwd(ch_dir)
	source("Load.R")
	setwd(p_dir)
	sim.from.file(input_file,out_file)

} else if(args[1]=='c' && args[2]=='s')
{

	input_file=args[3]
	out_file=args[4]
	p_dir=getwd()
	ch_dir=paste(p_dir,"/Script/Yeast/CC/Run/",sep="")
	setwd(ch_dir)
	source("Load.R")
	setwd(p_dir)
	sim.from.file(input_file,out_file)

} else
{
	cat("Please run the script like: Rscript main.R <b/c> <h/s> <input_file> <output_file>\n")
	cat("Example: Rscript main.R b h input.txt output.txt\n")
	cat("b:\tBP ontology\tc:CC ontology\n")
	cat("h:\thuman annotation \ts:\tyeast annotation\n")
	q(save = "no", status = 0, runLast = TRUE)

}




