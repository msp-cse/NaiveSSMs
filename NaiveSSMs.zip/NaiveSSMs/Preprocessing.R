args <- commandArgs(trailingOnly = TRUE)
if(length(args)<2)
{
	cat("Insufficient arguments!\n")
	cat("Please run the script like: Rscript Preprocessing.R <b/c> <h/s>\n")
	cat("b:\tBP ontology\tc:CC ontology\n")
	cat("h:\thuman annotation \ts:\tyeast annotation\n")
	q(save = "no", status = 0, runLast = TRUE)

}else if(length(args)>2)
{
	cat("More than required arguments!\n")
	cat("Please run the script like: Rscript Preprocessing.R <b/c> <h/s>\n")
	cat("b:\tBP ontology\tc:CC ontology\n")
	cat("h:\thuman annotation \ts:\tyeast annotation\n")
	q(save = "no", status = 0, runLast = TRUE)

} else if(args[1]=='b' && args[2]=='h')
{
	p_dir=getwd()
	ch_dir=paste(p_dir,"/Script/Human/BP/Preprocessing/",sep="")
	setwd(ch_dir)
	source('Hs_BP_Preprocessing.R')
	setwd(p_dir)

} else if(args[1]=='b' && args[2]=='s')
{
	p_dir=getwd()
	ch_dir=paste(p_dir,"/Script/Yeast/BP/Preprocessing/",sep="")
	setwd(ch_dir)
	source('Sc_BP_Preprocessing.R')
	setwd(p_dir)

} else if(args[1]=='c' && args[2]=='h')
{
	p_dir=getwd()
	ch_dir=paste(p_dir,"/Script/Human/CC/Preprocessing/",sep="")
	setwd(ch_dir)
	source('Hs_CC_Preprocessing.R')
	setwd(p_dir)

} else if(args[1]=='c' && args[2]=='s')
{
	p_dir=getwd()
	ch_dir=paste(p_dir,"/Script/Yeast/CC/Preprocessing/",sep="")
	setwd(ch_dir)
	source('Sc_CC_Preprocessing.R')
	setwd(p_dir)
} else
{
	cat("Please run the script like: Rscript Preprocessing.R <b/c> <h/s>\n")
	cat("b:\tBP ontology\tc:CC ontology\n")
	cat("h:\thuman annotation \ts:\tyeast annotation\n")
	q(save = "no", status = 0, runLast = TRUE)
}
