#ratio beteen sum of weighted and unweighted edges of the subgraph consisting of t and its ancestors to the subgraph consisting of t 
#and its ancestors and descendants
rel.edge.IC <- function(t)	#added
{
	t = as.character(t)
	if(t==BP_root)
		return(0)

	desc=get(t,GOBPOFFSPRING)
	if(all(is.na(desc)))
		return(1)		#if t=leaf 

	anc=get(t,GOBPANCESTOR)
	anc=anc[anc!="all"]	# remove the ancestor "all"
	sg_anc=subGraph(c(anc,t),BP_DAG)
	edges_anc=edges(sg_anc)
	nodes_anc=nodes(sg_anc)

	nodes_anc=nodes_anc[nodes_anc!=BP_root]
	weight_anc=0
	for(i in nodes_anc)
	{
		E=edges_anc[[i]]
		for(j in E)
			weight_anc=weight_anc+edge.weight(i,j)
	}
	

	sg_anc_desc=subGraph(c(anc,desc,t),BP_DAG)
	edges_anc_desc=edges(sg_anc_desc)
	nodes_anc_desc=nodes(sg_anc_desc)

	nodes_anc_desc=nodes_anc_desc[nodes_anc_desc!=BP_root]
	weight_anc_desc=0
	for(i in nodes_anc_desc)
	{
		E=edges_anc_desc[[i]]
		for(j in E)
			weight_anc_desc=weight_anc_desc+edge.weight(i,j)
	}

	return((weight_anc+numEdges(sg_anc))/(weight_anc_desc+numEdges(sg_anc_desc)))
	
}
