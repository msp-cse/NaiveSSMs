# for each term, no. of annotations of the term and its ancestors
all.annotations.ancestors <- function()
{
	BP_ancestor_annotation=NULL
#	count=0
	N=nodes(BP_DAG)
	N=N[N!="all"]	
	for(i in N)
	{
		BP_ancestor_annotation=c(BP_ancestor_annotation, ancestor.annotation(i))

#		count=count+1
#		print(count)
	}
	names(BP_ancestor_annotation)=N
	return(BP_ancestor_annotation)

}
