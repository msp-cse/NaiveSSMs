# No. of annotations of a GO term t and its ancestors
ancestor.annotation <- function(t)
{
	t = as.character(t)
	if(t==BP_root)
		return(length(annotations(t)))

	anc=get(t,GOBPANCESTOR)
	anc=anc[anc!="all"]	# remove the ancestor "all"
	ant_anc=NULL
	for(i in anc)
		ant_anc=c(ant_anc,annotations(i))
	ant_anc=c(ant_anc,annotations(t))	#Including t's annotation
	return(length(unique(ant_anc)))
}
