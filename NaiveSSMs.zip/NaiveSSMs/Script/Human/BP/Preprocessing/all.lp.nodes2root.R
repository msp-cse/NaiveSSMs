
#Longest paths from each node to root
all.lp.nodes2root <- function()
{	
	torder=tsort(BP_DAG_REV)
	dist=lp.source2others(BP_DAG_REV,torder,BP_root)
	names(dist)=torder	
# Both 'source' and 'all' nodes are present in the dist vector
	return(dist)
}

