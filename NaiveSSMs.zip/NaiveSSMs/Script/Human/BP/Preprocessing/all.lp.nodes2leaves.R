#longest paths (assuming reverse direction) from each node to any leaf.
#Path is computed indirectly; We include a 'source' node and one edge from source to each leaf.
#Since all leaves are now connected by source, the computed path will be longest path from 'source' to the referenced node, 
#i.e., path from the deepest leaf to the referenced node + 1

all.lp.nodes2leaves <- function()
{	
	x=leaves(BP_DAG,degree.dir="in")	#vector of leaves of BP_DAG
	sg=addNode('source',BP_DAG)	#add a node 'source'
 	sg=addEdge("source", x, sg, rep(1,length(x)))	#add edgess from 'source' to all leaves
	torder=tsort(sg)
	dist=lp.source2others(sg,torder,'source')
	names(dist)=torder	
# Both 'source' and 'all' nodes are present in the dist vector, so to find longest path these two nodes need to be considered.
# The longest path from a node t to any leaf is dist[[t]] - 1 
	return(dist)
}
