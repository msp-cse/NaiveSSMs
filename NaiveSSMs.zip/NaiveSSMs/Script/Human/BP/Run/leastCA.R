#compute least common ancestor
leastCA <- function(s,t)
{
	s = as.character(s)
	t = as.character(t)
	if(s==BP_root || t==BP_root)
		return(BP_root)
	if(s==t)
		return(s)

	anc1=get(s,GOBPANCESTOR)	
	anc2=get(t,GOBPANCESTOR)
	anc=intersect(anc1,anc2)
	anc=anc[anc!="all"]	# remove the ancestor "all"

	if(length(anc)==1)
		return(BP_root)

######################################
#	Time consuming
#	sg=subGraph(anc,BP_DAG)
#	sgrev <- reverseEdgeDirections(sg)
#	torder=tsort(sgrev)
#	dist=lp.source2others(sgrev, torder, BP_root)
#	x=torder[which(dist==max(dist))]
########################################

	lca=NULL
	for(i in anc)
		lca=c(lca,BP_LONGEST_PATH_NODE2ROOT[i])

	x=names(lca[which(lca==max(lca))])

	if(length(x)==1)
		return(x)
	else
		return(x[1])
}

