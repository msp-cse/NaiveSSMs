#sum of ancestors of t and their annotations divided by sum of ancestors and descendants and their annotations 
rel.IC <- function(t)	#added
{
	t = as.character(t)
#	if(t==BP_root)	#removed
#		return(0)	#removed

	desc=get(t,GOBPOFFSPRING)
	if(all(is.na(desc)))
		return(1)
	
	ant_anc=BP_ANCESTOR_ANNOTATION[[t]]
	ant_desc=all.annotations(t)	# no. of annotations of t and its descendants

	ant_desc=ant_desc-length(annotations(t))	#removing t's annotation
	
##################################################
	anc=get(t,GOBPANCESTOR)
	anc=anc[anc!="all"]	# remove the ancestor "all"
#################################################

	rIC=(ant_anc+length(anc)+1)/(ant_anc+ant_desc + length(unique(c(desc,anc)))+1)

	return(rIC)
}
