# relative edge based specificity for each term
all.rel.edge.IC <- function()
{
#	count=0
	rel_edge_IC=NULL
	N=nodes(CC_DAG)
	N=N[N!="all"]	
	for(i in N)
	{
		rel_edge_IC=c(rel_edge_IC, rel.edge.IC(i))
#		count=count+1
#		print(count)
	}
	
	names(rel_edge_IC)=N
	return(rel_edge_IC)
}

