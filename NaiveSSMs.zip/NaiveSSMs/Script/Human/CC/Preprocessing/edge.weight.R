#weight of an edge (u,v)
edge.weight <- function(u,v)
{
	u = as.character(u)
	v = as.character(v)
	w=length(annotations(u))+length(annotations(v))
	return(w)
}

