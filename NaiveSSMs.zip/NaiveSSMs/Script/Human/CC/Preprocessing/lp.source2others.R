# longest path length vector from term t to other nodes in DAG sg and torder is the topological order of sg
lp.source2others <- function(sg, torder, t)
{
	t = as.character(t)
	temp=which(torder==t)
	if(length(temp)==0)
		return(NA)		
	dist=rep(-100,length(torder))
	dist[which(torder==t)]=0	#assigned 0 to the source nodes and rest are negative values (say -100)
	l_torder=length(torder)
	for(i in 1:l_torder)
	{
		adj_nodes=adj(sg,torder[i])[[1]]	#creating vector of adjacency nodes from list 
		l_adj=length(adj_nodes)	#finding no. of adjacency nodes
		if(l_adj>0)
		{
			for(j in 1:l_adj)
			{
				v=which(torder==adj_nodes[j])	#finding index of j-th adjacent node in torder
				if(dist[v]<(dist[i]+1))
				{	
					dist[v]=dist[i]+1
				}
			}
		}
	}

	return(dist)

}


