# for each term, no. of annotations of the term and its ancestors
all.annotations.ancestors <- function()
{
	CC_ancestor_annotation=NULL
#	count=0
	N=nodes(CC_DAG)
	N=N[N!="all"]	
	for(i in N)
	{
		CC_ancestor_annotation=c(CC_ancestor_annotation, ancestor.annotation(i))

#		count=count+1
#		print(count)
	}
	names(CC_ancestor_annotation)=N
	return(CC_ancestor_annotation)

}
