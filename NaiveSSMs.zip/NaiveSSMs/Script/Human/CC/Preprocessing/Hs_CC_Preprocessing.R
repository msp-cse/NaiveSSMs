library(GO.db)
library(org.Hs.eg.db)
library(graph)
library(RBGL)
#graph CC_DAG, CC_DAG_REV are global variables
xx=toTable(GOCCPARENTS)	
CC_DAG=ftM2graphNEL(as.matrix(xx[, 1:2]), W=rep(1,dim(xx)[1]))
CC_DAG_REV=ftM2graphNEL(as.matrix(xx[, c(2,1)]), W=rep(1,dim(xx)[1]))

CC_root="GO:0005575"

source('annotations.R')
source('all.annotations.R')
source('all.annotations.ancestors.R')
source('all.lp.nodes2leaves.R')
source('all.lp.nodes2root.R')
source('all.rel.edge.IC.R')
source('ancestor.annotation.R')
source('lp.source2others.R')
source('rel.edge.IC.R')
source('edge.weight.R')

cat("\nPreprocessing of CC ontology with human annotation going on...")
CC_NUM_ANT=all.annotations(CC_root)
CC_LONGEST_PATH_NODE2ROOT=all.lp.nodes2root()
CC_LONGEST_PATH_LEAVES2NODE=all.lp.nodes2leaves()
CC_ANCESTOR_ANNOTATION=all.annotations.ancestors()
CC_REL_EDGE_IC=all.rel.edge.IC()
CC_LONGEST_PATH=CC_LONGEST_PATH_LEAVES2NODE[CC_root]-1


save(CC_DAG, CC_DAG_REV, CC_root, CC_NUM_ANT, CC_LONGEST_PATH_NODE2ROOT, CC_LONGEST_PATH_LEAVES2NODE, CC_LONGEST_PATH, CC_ANCESTOR_ANNOTATION, CC_REL_EDGE_IC, file="Hs_CC_Drop_IEA_Objects.RData")
cat("\nPreprocessing completed successfully...\n")
