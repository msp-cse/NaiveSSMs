
#Longest paths from each node to root
all.lp.nodes2root <- function()
{	
	torder=tsort(CC_DAG_REV)
	dist=lp.source2others(CC_DAG_REV,torder,CC_root)
	names(dist)=torder	
# Both 'source' and 'all' nodes are present in the dist vector
	return(dist)
}

