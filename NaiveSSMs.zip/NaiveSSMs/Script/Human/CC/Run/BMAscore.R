#return BMA from the score matrix
BMAscore <- function(mat)
{
	row_max=0
	col_max=0
	r=nrow(mat)
	c=ncol(mat)
	for(i in 1:r)
		row_max=row_max+max(mat[i,])

	for(i in 1:c)
		col_max=col_max+max(mat[,i])
	BMA=(row_max + col_max)/(r+c)
	return(BMA)
}
