sim.from.file <- function(input_file,output_file)
{
	pp_data <- read.table(input_file, sep="\t")
	cat("#gene_id1", "gene_id2","RDS_max", "RDS_BMA","RNS_max","RNS_BMA","RES_max", "RES_BMA", file=output_file, sep="\t", append=FALSE)
	cat("\n", file=output_file, append=TRUE)
	len=length(pp_data[[1]])
	cat("\nComputation going on...")
	for(i in 1:len)
	{
		gene1=as.character(pp_data[[1]][i])
		gene2=as.character(pp_data[[2]][i])
		
		sim=sim.between2genes(gene1, gene2)
	
		sim=round(sim,digit=2)
		if(any(is.na(sim)))
		{
			cat(gene1, gene2, sim, sep="\t")
			cat("\n")	
			cat("Input data is not good")
			cat("\n")
			q(save = "no", status = 0, runLast = TRUE)
		}

		cat(gene1, gene2, sim, file=output_file, sep="\t", append=TRUE)
		cat("\n", file=output_file, append=TRUE)	# Need to print "\n" seperately to scan data correctly with read.table()
	}
	cat("\nCompleted successfully.\n")
}

