sim.between2genes <- function(gene1, gene2)
{

	gene1 = as.character(gene1)
	gene2 = as.character(gene2)
	goids1=gene2goids(gene1)
	goids2=gene2goids(gene2)

	if(is.na(goids1) || is.na(goids2))
		return(NA)	

	max_dtr2dltr=0
	

	max_rel_IC=0		#Relative IC	
	
	max_rel_edge_IC=0
	

	len1=length(goids1)
	len2=length(goids2)
	BMAmat=matrix(nrow=len1,ncol=len2,byrow=T)	#for calculating BMA score

	BMA_dtr2dltr=matrix(nrow=len1,ncol=len2,byrow=T)
	
	


	
	BMA_rel_IC=matrix(nrow=len1,ncol=len2,byrow=T)	
	
	BMA_rel_edge_IC=matrix(nrow=len1,ncol=len2,byrow=T)
	
	
	LCAs=NULL
	rLCAs=NULL	#LCAs for repeated pairs
	goids1_pair=NULL	#to record 1st GO terms of generated pairs of goids
	goids2_pair=NULL	#to record 2nd GO terms of generated pairs of goids
	for(i in 1:len1)
	{
		for(j in 1:len2)
		{
#need to check reverse way, i.e., whether same pair (A, B) in reverse way (B, A) is generated or not
			matched=intersect(which(goids1_pair==goids2[j]), which(goids2_pair==goids1[i])) 

			if(length(matched)==0)							#the pair is not generated reverse way
			{
				BMAmat[i,j]=leastCA(goids1[i],goids2[j])
				LCAs=c(LCAs,BMAmat[i,j])
				goids1_pair=c(goids1_pair,goids1[i])
				goids2_pair=c(goids2_pair,goids2[j])			
			}
			else
			{
				BMAmat[i,j]=LCAs[matched]
				rLCAs=c(rLCAs,BMAmat[i,j])
			}
		}
	}


##########################
	LCAs=c(LCAs,rLCAs)
	uLCAs=unique(LCAs,NULL)	#unique LCAs


	for(term in uLCAs)
	{

		indices=which(BMAmat==term)	#return indices by column wise count
		col_indices=NULL
		row_indices=NULL
		for(i in indices)		# finding indices of t-th LCA in BMA score matrix by dividing  no. of rows
		{
			col_indices=c(col_indices,ceiling(i/length(goids1)))	# column indices of t-th LCA in BMA score matrix 
			if((i%%length(goids1))!=0)					
				row_indices=c(row_indices, i%%length(goids1))	# row indices of t-th LCA in BMA score matrix
			else
				row_indices=c(row_indices,length(goids1))		# row indices of t-th LCA in BMA score matrix
		}

		times=length(which(LCAs==term))	#No. of occurrances of t-th LCA for avg score

##################################################################################
#		lp_root2node=lp.node2root(t)		#Time consuming

#CC_LONGEST_PATH_LEAVES2NODE[] also includes both 'source' and 'all' nodes; 'source' is a single leaf node of the graph and 'all' is the root of the graph; 
#1 is subtracted because it is the longest path from 'source' to the referenced node (t), 
#i.e., longest path (assuming reverse direction) from the referenced node to any leaf
		
		lp_node2root=CC_LONGEST_PATH_NODE2ROOT[[term]]
		lp_root2node2leaf=CC_LONGEST_PATH_LEAVES2NODE[[term]] - 1 + lp_node2root

		dtr2dltr=lp_node2root/lp_root2node2leaf
		if(max_dtr2dltr < dtr2dltr )
				max_dtr2dltr=dtr2dltr
		
		for(i in 1:length(indices))	#making BMA score matrix
			BMA_dtr2dltr[row_indices[i],col_indices[i]]=dtr2dltr




##################################################################################
		rel_IC=rel.IC(term)
		if(max_rel_IC < rel_IC)
			max_rel_IC=rel_IC



		for(i in 1:length(indices))	#making BMA score matrix
			BMA_rel_IC[row_indices[i],col_indices[i]]=rel_IC




###################################################################################

		rel_edge_IC=CC_REL_EDGE_IC[[term]]
		if(max_rel_edge_IC < rel_edge_IC)
			max_rel_edge_IC=rel_edge_IC

		for(i in 1:length(indices))	#making BMA score matrix
			BMA_rel_edge_IC[row_indices[i],col_indices[i]]=rel_edge_IC




	}


###############################


	BMA_dtr2dltr=BMAscore(BMA_dtr2dltr)
	
	BMA_rel_IC=BMAscore(BMA_rel_IC)

	BMA_rel_edge_IC=BMAscore(BMA_rel_edge_IC)
	

#####################################################################################

	c1=c(max_dtr2dltr, BMA_dtr2dltr)

	c2=c(max_rel_IC, BMA_rel_IC)
		
	c3=c(max_rel_edge_IC, BMA_rel_edge_IC)
	

	return(c(c1,c2,c3))	

}
