#compute least common ancestor
leastCA <- function(s,t)
{
	s = as.character(s)
	t = as.character(t)
	if(s==CC_root || t==CC_root)
		return(CC_root)
	if(s==t)
		return(s)

	anc1=get(s,GOCCANCESTOR)	
	anc2=get(t,GOCCANCESTOR)
	anc=intersect(anc1,anc2)
	anc=anc[anc!="all"]	# remove the ancestor "all"

	if(length(anc)==1)
		return(CC_root)

######################################
#	Time consuming
#	sg=subGraph(anc,CC_DAG)
#	sgrev <- reverseEdgeDirections(sg)
#	torder=tsort(sgrev)
#	dist=lp.source2others(sgrev, torder, CC_root)
#	x=torder[which(dist==max(dist))]
########################################

	lca=NULL
	for(i in anc)
		lca=c(lca,CC_LONGEST_PATH_NODE2ROOT[i])

	x=names(lca[which(lca==max(lca))])

	if(length(x)==1)
		return(x)
	else
		return(x[1])
}

