# all direct annotations of a GO term only
annotations <- function(goterm)
{
	goterm = as.character(goterm)
	genes=org.Hs.egGO2EG[[goterm]]
	if(length(genes)==0)
		return(NA)
	genes_exceptIEA=NULL
	for(i in 1:length(genes))
		if(names(genes[i]) != "IEA")
			genes_exceptIEA=c(genes_exceptIEA, genes[i])

	return(genes_exceptIEA)

}

