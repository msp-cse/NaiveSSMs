#no. of annotations of a GO term and its descendants
all.annotations <- function(goterm)
{

	goterm = as.character(goterm)

#	if(goterm==BP_root)
#		return(BP_NUM_ANT)

	genes=org.Sc.sgdGO2ALLORFS[[goterm]]
	if(length(genes)==0)
		return(0)
	genes_exceptIEA=NULL
	for(i in 1:length(genes))
		if(names(genes[i]) != "IEA")
			genes_exceptIEA=c(genes_exceptIEA, genes[i])
		
	return(length(genes_exceptIEA))	

}

