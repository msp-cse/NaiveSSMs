library(GO.db)
library(org.Sc.sgd.db)
library(graph)
library(RBGL)
#graph BP_DAG, BP_DAG_REV are global variables
xx=toTable(GOBPPARENTS)	
BP_DAG=ftM2graphNEL(as.matrix(xx[, 1:2]), W=rep(1,dim(xx)[1]))
BP_DAG_REV=ftM2graphNEL(as.matrix(xx[, c(2,1)]), W=rep(1,dim(xx)[1]))

BP_root="GO:0008150"

source('annotations.R')
source('all.annotations.R')
source('all.annotations.ancestors.R')
source('all.lp.nodes2leaves.R')
source('all.lp.nodes2root.R')
source('all.rel.edge.IC.R')
source('ancestor.annotation.R')
source('lp.source2others.R')
source('rel.edge.IC.R')
source('edge.weight.R')


cat("\nPreprocessing of BP ontology with yeast annotation going on...")
BP_NUM_ANT=all.annotations(BP_root)
BP_LONGEST_PATH_NODE2ROOT=all.lp.nodes2root()
BP_LONGEST_PATH_LEAVES2NODE=all.lp.nodes2leaves()
BP_ANCESTOR_ANNOTATION=all.annotations.ancestors()
BP_REL_EDGE_IC=all.rel.edge.IC()
BP_LONGEST_PATH=BP_LONGEST_PATH_LEAVES2NODE[BP_root]-1

save(BP_DAG, BP_DAG_REV, BP_root, BP_NUM_ANT, BP_LONGEST_PATH_NODE2ROOT, BP_LONGEST_PATH_LEAVES2NODE, BP_LONGEST_PATH, BP_ANCESTOR_ANNOTATION, BP_REL_EDGE_IC, file="Sc_BP_Drop_IEA_Objects.RData")
cat("\nPreprocessing completed successfully...\n")
