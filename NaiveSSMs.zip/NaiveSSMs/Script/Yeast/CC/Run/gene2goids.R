
#retuen vector of GO IDs  being annotated by a gene
gene2goids <- function(gene) 
{
    gene = as.character(gene)
    goid_list = org.Sc.sgdGO[[gene]]	#gene should be given as ORF ID
	if(length(goid_list)==1)	#if the gene is not present in org.Sc.sgdGO
		if(is.na(goid_list))
			return(NA)

	goids=NULL
	
	for(i in goid_list) 
	{

		if(i$Evidence != "IEA" && i$Ontology == "CC")

		{
			 goids=c(goids, i$GOID)
		}
	}
	if (length(goids) == 0)
	   return (NA)
	goids = as.character(unique(goids))
	
	return(goids)
}
